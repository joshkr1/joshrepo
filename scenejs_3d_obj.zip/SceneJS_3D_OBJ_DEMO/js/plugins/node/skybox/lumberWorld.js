/**
 * Skybox node type, with the Lumberjack World
 *
 * @author B.Bartel & E.Mazur
 *
 * Usage example:
 *
 * someNode.addNode({
 *      type: "skybox/lumberWorld"
 *  });
 */
SceneJS.Types.addType("skybox/lumberWorld", {
    construct:function (params) {

        // Wraps a 'custom' skybox node type, passing in the stormyDays texture
        this.addNode({
            type:"skybox",
            src:SceneJS.getConfigs("pluginPath") + "/node/skybox/textures/lumberWorld.jpg"
        })
    }
});
